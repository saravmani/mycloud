import { Component, OnInit, Input } from '@angular/core'; 
import { CardManager } from "app/services/card-manager-service.";
 

@Component({
  selector: 'SilverCard-card',
  moduleId: module.id,
  templateUrl: 'SilverCard.component.html',
    styleUrls: ['silvercard.css']

})

export class SilverCard implements OnInit {
    @Input() cardDetails: any
  ngOnInit(): void {

  }
  constructor(private objCardManager: CardManager) {
    
    this.objCardManager.cardDetailsPublisher.subscribe((cardData) => {
      this.cardDetails = cardData;
    })
  }

}
