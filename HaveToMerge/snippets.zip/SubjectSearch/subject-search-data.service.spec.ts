/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { SubjectSearchDataService } from './subject-search-data.service';

describe('SubjectSearchDataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SubjectSearchDataService]
    });
  });

  it('should ...', inject([SubjectSearchDataService], (service: SubjectSearchDataService) => {
    expect(service).toBeTruthy();
  }));
});
