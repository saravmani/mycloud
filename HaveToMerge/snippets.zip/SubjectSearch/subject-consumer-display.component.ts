import { Component, OnInit, Input, EventEmitter, Output, ElementRef, Renderer } from '@angular/core';
import { SubjectSearchDataService } from './subject-search-data.service';
import { SessionHandlerService } from '../Utils/session-handler.service';

declare var $:any;

@Component({
  selector: 'subject-consumer-display',
  templateUrl: './subject-consumer-display.component.html',
  styles: []
})

export class SubjectConsumerDisplayComponent extends SessionHandlerService  implements OnInit {
  @Output() onGenerate = new EventEmitter<any>();
  constructor(private objRenderer: Renderer,  private objSubjectSearchDataService: SubjectSearchDataService) { 
    super();
  }
  @Input() subjectInfo: any;
  ngOnInit() {

  }
  GenerateClick(elementObject: Element) {

    var objElementRef = new ElementRef(elementObject);
    this.objRenderer.setElementAttribute(objElementRef.nativeElement.target, "disabled", "disabled");
    this.onGenerate.emit(this.subjectInfo);
  }

  
  public getAddress(RUIDKey)
  {
    var objReqAddress = new ReqAddress();
    objReqAddress.RUID = this.subjectInfo.RUID;
    objReqAddress.ISCONSUMER = "1";

    this.objSubjectSearchDataService.getAddress($.param(objReqAddress)).subscribe((AddressInfoJson) => {
        $("#aAddress"+RUIDKey).attr("style", "display:none");
        $("#GenAddressSpan"+RUIDKey).text(AddressInfoJson.Address);
        $("#GenAddressSpan"+RUIDKey).focus();
    });
  }

  public UpdateMergeList(RUID, IsAddition)
  {
    var subjectInfoLst = this.getSession("SubjectInfoList");
    
    $(subjectInfoLst).filter(function (idx) {
                if(subjectInfoLst[idx].RUID === RUID)
                  subjectInfoLst[idx].IsMerged = IsAddition;
            });
    
    this.addSession("SubjectInfoList",subjectInfoLst);
  }
  

public checkBoxClick(selRUIDKey) {
  
      var selectedRUIDs = this.getSession("selectedRUIDs");
      var subjectInfoLst = this.getSession("SubjectInfoList");
      //var selectedData = this.getSession("selectedData");
      var RUID = this.subjectInfo.RUID;

    if ($('#' + selRUIDKey).prop('checked') === true) {
      
        if (selectedRUIDs.length < 10) {
            selectedRUIDs.push(RUID);

        this.UpdateMergeList(RUID, true);
            //selectedData.push(filterResult[0]);

        } else {
            $('#' + selRUIDKey).prop('checked', false);
            //$('#vwConfirmationMaxMergeCount').modal('show');
        }
    } else {
        selectedRUIDs.splice($.inArray(RUID, selectedRUIDs), 1);
        this.UpdateMergeList(RUID, false);
        //selectedData.splice($.inArray(RUID, selectedData), 1);

    }

    this.addSession("selectedRUIDs", selectedRUIDs);
    //this.addSession("selectedData", selectedData);
    
}



public vwConfirmationMaxMergeCount() {

   // $('#vwConfirmationMaxMergeCount').modal('hide');
}

}

class ReqAddress {
    RUID;
    ISCONSUMER;

}