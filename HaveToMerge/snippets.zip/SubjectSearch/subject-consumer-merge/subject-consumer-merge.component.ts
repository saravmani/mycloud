
import { Component, OnInit, Input, EventEmitter, Output, ElementRef, Renderer } from '@angular/core';
import { SubjectSearchDataService } from '../subject-search-data.service';
import { SessionHandlerService } from '../../Utils/session-handler.service';

declare var $: any;

@Component({
  selector: 'subject-consumer-merge',
  templateUrl: './subject-consumer-merge.component.html'
})

export class SubjectConsumerMergeComponent extends SessionHandlerService  implements OnInit {
  public selectedData;
  
  constructor(private objRenderer: Renderer,  private objSubjectSearchDataService: SubjectSearchDataService) { 
    super();
  }
  
  ngOnInit() {

var RUIDListForServer = "";
var MergedRUID = "";
var MergedName = "";
var MergedScore = "";
var MergedInquiryMasterId = "";
var index = 0;
 var subjectInfoLst = this.getSession("SubjectInfoList");
    var data = new Array();
    var vSelected = "";
    $(subjectInfoLst).filter(function (idx) {
        if(subjectInfoLst[idx].IsMerged)
        {
          data.push(subjectInfoLst[idx]);   

          RUIDListForServer += subjectInfoLst[idx].RUID +",";
          if(index === 0)
          {
            index++;
              MergedRUID = subjectInfoLst[idx].RUID;
              MergedName = subjectInfoLst[idx].Name;
              MergedScore = subjectInfoLst[idx].SearchConfidenceScore;
              MergedInquiryMasterId = subjectInfoLst[idx].Inq_Master_ID;                    
          }
        }
    });
            
    RUIDListForServer = RUIDListForServer.substring(0, RUIDListForServer.length-1);

    this.addSession("MergedRUID", RUIDListForServer);
    this.addSession("MergedName",MergedName);
    this.addSession("MergedScore",MergedScore);
    this.addSession("MergedInquiryMasterId",MergedInquiryMasterId);
    this.selectedData = data;
  }

  public OnMergerClick(RUID, Name, Score, InqId)
  {
    var RUIDListForServer = RUID + ",";
    var subjectInfoLst = this.getSession("SubjectInfoList");
    var data = new Array();
    $(subjectInfoLst).filter(function (idx) {
                if(subjectInfoLst[idx].IsMerged && subjectInfoLst[idx].RUID != RUID)
                            RUIDListForServer += subjectInfoLst[idx].RUID +",";
            });

    RUIDListForServer = RUIDListForServer.substring(0, RUIDListForServer.length-1);

    this.addSession("MergedRUID",RUIDListForServer);
    this.addSession("MergedName",Name);
    this.addSession("MergedScore",Score);
    this.addSession("MergedInquiryMasterId",InqId);
    
  }

}