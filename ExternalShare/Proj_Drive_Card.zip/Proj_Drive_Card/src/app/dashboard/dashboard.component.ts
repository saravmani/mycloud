import { Component, OnInit, AfterContentInit, DoCheck } from '@angular/core';
import { GoogleDriveProvider } from 'app/services/google-drive-service';
import { DriveFile } from "app/services/IDriveConnector";


declare var $: any;

@Component({
  selector: 'dashboard-cmp',
  moduleId: module.id,
  templateUrl: 'dashboard.component.html'
})

export class DashboardComponent implements OnInit, AfterContentInit {

  filelist: Array<DriveFile> = new Array<DriveFile>();

  constructor(private objGoogleDriveProvider: GoogleDriveProvider) { }
  ngOnInit() {

  }
  initDrive() {
    this.objGoogleDriveProvider.initDrive().subscribe(isSignedIn => {
      if (isSignedIn) {
        this.fetchDirListFromGoogleDrive();
      }
    });

  }

  fetchFileList()
  { this.initDrive(); }

  fetchDirListFromGoogleDrive() {

    this.objGoogleDriveProvider.fetchFilesFromDerive()
      .then(data => {
        this.filelist = data;
        console.log(this, this.filelist);
      });

  }

  ngAfterContentInit(): void {
    this.initDrive();

  }

}
