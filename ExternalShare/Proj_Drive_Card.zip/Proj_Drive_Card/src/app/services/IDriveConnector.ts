import { Observable } from "rxjs/Observable";

export interface IDriveConnector {
    isSignedIn: boolean;
    initDrive(): Observable<boolean>;
    doSineIn();
    doSineOut();
    fetchFilelist():Array<DriveFile>;
}

export class DriveFile {
    fileName: string;
    fileMimeType: string;
    viewedByMeTime: string;
    modifiedTime: string;
    mimeType:string;
    
    //We can able add more generic properties here
}