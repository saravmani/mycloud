import { Component, OnInit, Input } from '@angular/core';
import { DriveFile } from "app/services/IDriveConnector";


declare var $: any;

@Component({
  selector: 'drive-item',
  moduleId: module.id,
  templateUrl: 'DriveItemDisplay.Component.html',

})

export class DriveItem implements OnInit {
  @Input() DriveFileItem: DriveFile
  ngOnInit(): void {

  }
  constructor() {

  }

  getIconClass(mimeType) {
    switch (mimeType) {
      case "text/plain":
        return 'ti-align-justify';
      case "application/vnd.google-apps.folder":
        return 'ti-folder';
      case "image/jpeg":
        return 'ti-image';
      case "application/vnd.google-apps.spreadsheet":
        return 'ti-layout-grid4'; 
      default:
        break;
    }

    return 'ti-na';

  }

}
