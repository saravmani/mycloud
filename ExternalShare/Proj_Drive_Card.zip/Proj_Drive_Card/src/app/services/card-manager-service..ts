import { Injectable } from "@angular/core";
import { Observable, BehaviorSubject, Subject } from "rxjs/Rx";

@Injectable()
export class CardManager {
    cardDetailsPublisher: Observable<any>;
    cardDetailsBehaviorSubject: BehaviorSubject<any>;
    constructor() {
        this.cardDetailsBehaviorSubject = new BehaviorSubject<any>(null);
        this.cardDetailsPublisher = this.cardDetailsBehaviorSubject.asObservable();
    }
    publishCardDetails(cardDetails: any) {
        this.cardDetailsBehaviorSubject.next(cardDetails.value);
    }
}