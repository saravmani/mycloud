import { Injectable } from '@angular/core';
import { CometService } from '../Utils/CometServices/comet.service';
import { LoggServiceService } from '../Utils/loggin-service.service';
import { Observable } from 'rxjs/Rx';
import { ComponentBase } from '../rptEngineBase/rpt-base';
import { Http, RequestOptionsArgs, Headers, Response } from '@angular/http';
import { ReportEngineServiceUrls } from "../ServiceURLConfiguration";

@Injectable()
export class SubjectSearchDataService extends ComponentBase {
  constructor(private objCometService: CometService, private objLoggServiceService: LoggServiceService) {
    super();
  }



  triggerReportEngine(dataTriggerRptEngine) {
    return this.objCometService.webAPIServiceCall(ReportEngineServiceUrls.triggerReportEngine, false, dataTriggerRptEngine)
    .map(data => { return this.objCometService.sessionValidation(data); });
      //.map((data) => { console.log(data); return data.json();
      //});
  }


  fetchConceptCodeList(domainCodeList: string): Observable<JSON> {
    return this.objCometService.webAPIServiceCall(ReportEngineServiceUrls.fetchConceptCodeList, true, domainCodeList)
    .map(data => { return this.objCometService.sessionValidation(data); });      
  }
  
    fetchProductList(CHS_Type: string): Observable<JSON> {
    return this.objCometService.webAPIServiceCall(ReportEngineServiceUrls.productList, true, CHS_Type)
      .map(data => { return this.objCometService.sessionValidation(data); });
  }

  getAddress(dataGetAddr) {
    return this.objCometService.webAPIServiceCall(ReportEngineServiceUrls.getAddress, false, dataGetAddr)
    .map(data => { return this.objCometService.sessionValidation(data); });
  }

}
