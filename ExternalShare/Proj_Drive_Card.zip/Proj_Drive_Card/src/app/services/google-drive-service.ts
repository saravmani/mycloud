import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable, BehaviorSubject, Subject } from "rxjs/Rx";
import { DriveFile, IDriveConnector } from "app/services/IDriveConnector";
declare var gapi: any;
@Injectable()
export class GoogleDriveProvider  {

    CLIENT_ID = '352039355119-njf5fulv7l9e95lh304anovtc4592p5m.apps.googleusercontent.com';
    API_KEY = 'AIzaSyCsFRbMzvM4bT7oAmn5OxxlME_fPxBptNw';
    DISCOVERY_DOCS = ["https://www.googleapis.com/discovery/v1/apis/drive/v3/rest"];
    SCOPES = 'https://www.googleapis.com/auth/drive.metadata.readonly';

    _objClientInitSubject: BehaviorSubject<boolean>;
    _objClientInitObser: Observable<boolean>;
    isSignedIn: boolean;
    constructor() {
        this._objClientInitSubject = new BehaviorSubject<boolean>(null);
        this._objClientInitObser = this._objClientInitSubject.asObservable();
    }

    /**
     *  On load, called to load the auth2 library and API client library.
     */
    initDrive(): Observable<boolean> {
        gapi.load('client:auth2', () => {
            this.initClient();
        });
        return this._objClientInitObser;
    }


    /**
     *  Initializes the API client library and sets up sign-in state
     *  listeners.
     */
    initClient() {
        gapi.client.init({
            apiKey: this.API_KEY,
            clientId: this.CLIENT_ID,
            discoveryDocs: this.DISCOVERY_DOCS,
            scope: this.SCOPES
        }).then(() => {
            // Listen for sign-in state changes.
            gapi.auth2.getAuthInstance().isSignedIn.listen((isSignedIn) => { this.updateSigninStatus(isSignedIn) });
            // Handle the initial sign-in state.
            this.updateSigninStatus(gapi.auth2.getAuthInstance().isSignedIn.get());
        });
    }

    /**
     *  Called when the signed in status changes, to update the UI
     *  appropriately. After a sign-in, the API is called.
     */
    updateSigninStatus(isSignedIn) {
        this.isSignedIn = isSignedIn;
        if (!isSignedIn) {
            gapi.auth2.getAuthInstance().signIn();
        } else {
            this._objClientInitSubject.next(isSignedIn);

            // gapi.auth2.getAuthInstance().signIn();
        }
    }

    doSineIn() {
        gapi.auth2.getAuthInstance().signIn();
    }

    /**
     *  Sign out the user upon button click.
     */
    doSineOut(event) {
        gapi.auth2.getAuthInstance().signOut();
    }

    fileList: string;
    /**
     * Append a pre element to the body containing the given message
     * as its text node. Used to display the results of the API call.
     *
     * @param {string} message Text to be placed in pre element.
     */
    appendPre(message) {
        this.fileList += message;
    }

    getFileList() {
        return this.fileList;
    }


    fetchFilesFromDerive(): Promise<Array<DriveFile>> {
        return new Promise<Array<DriveFile>>(this.getFile);
    }

    private getFile(resolve) {
        gapi.client.drive.files.list({
            'pageSize': 20,//we can get this number from users
            'fields': "nextPageToken, files(id, name,mimeType,viewedByMeTime,modifiedTime)"
        }).then((response) => {
            var files = response.result.files;
            if (files && files.length > 0) {
                var filesList = new Array<DriveFile>();
                for (var i = 0; i < files.length; i++) {
                    var file = files[i];
                    filesList.push({
                        fileMimeType: file.mimeType,
                        fileName: file.name,
                        viewedByMeTime: file.viewedByMeTime,
                        modifiedTime: file.modifiedTime,
                        mimeType: file.mimeType,

                    });
                    resolve(filesList); 
                }
            } else {
                resolve(null);
            }
        });
    }

}