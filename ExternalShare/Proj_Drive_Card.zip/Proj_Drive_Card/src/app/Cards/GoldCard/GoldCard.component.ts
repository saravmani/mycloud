import { Component, OnInit, Input } from '@angular/core'; 
import { CardManager } from "app/services/card-manager-service.";


@Component({
  selector: 'gold-card',
  moduleId: module.id,
  templateUrl: 'GoldCard.component.html',
  styleUrls: ['goldcard.css']

})

export class GoldCard implements OnInit {
  @Input() cardDetails: any
  ngOnInit(): void {

  }
  constructor(private objCardManager: CardManager) {
    
    this.objCardManager.cardDetailsPublisher.subscribe((cardData) => {
      this.cardDetails = cardData;
    })
  }


}
