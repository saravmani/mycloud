import { Component, OnInit, ViewChild, ElementRef, HostListener, Renderer } from '@angular/core';
import { ModalDirective, DatePickerComponent } from 'ng2-bootstrap';
import { Router } from "@angular/router";
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { RptIndexComponent } from "../ReportComponents/rpt-index/rpt-index.component";
import { RenderSectionDataService, ReqSectionData } from '../RptEngProcessor/render-section-data.service';
import { Observable, Subject } from 'rxjs/Rx';
import { SubjectSearchDataService } from './subject-search-data.service';
import * as _ from 'lodash';
import { Http, RequestOptionsArgs, Headers, Response } from '@angular/http';
import { SessionHandlerService } from '../Utils/session-handler.service';

declare var datepickchange_cons: any;
declare var datepickchange_comm: any;
declare var notifications: any;
declare var objSignalRConnection: any;
declare var $: any;
declare var kendo: any;

declare var currentCulture: string;




function getWindow(): any {
    return window;
}

@Component({
    selector: 'subject-search-index',
    templateUrl: './subject-search.component.html',
    styles: []
})

export class SubjectSearchComponent extends SessionHandlerService implements OnInit {

    reportBaseId: number;
    reportName: string;
    generatedReportId: number;//sb_report_details table's record id 
    InquiryMasterId: number;//sb_inquiry table's record id 
    RUIDTogenerateReport: string;//It will be stored in encrypted format
    private _defaultSearchType = "NMIDSRCH";
    private _defaultSsubjectType = "CONS";
    private _defaultGender = "001";
    private _requiredDomainCodeList = "SEARCHMETHODS_CON,SEARCHMETHODS_COM,CONSUMERIDTYPE,COMMERCIALIDTYPE,COUNTRY_OR_NATIONALITY,CHS_TYPE,CREDIT_FACILITY_TYPE,GENDER";
    public subjectSearchResult: any;
    public subjSrchForm: FormGroup;
    @ViewChild("cirModel") public cirModel: ModalDirective;
    @ViewChild("mergeModel") public mergeModel: ModalDirective;
    showReport: boolean;
    public _subjectType: string = this._defaultSsubjectType;
    private _subjectSearchType: string = this._defaultSearchType;
    public ConsumerProductControl;
    public consumerDisplayStyle = "display";
    public commercialDisplayStyle = "none";
    public selectedBaseProductId: number;
    public IsModalLoaded: boolean;

    public backGroundElementViewStatusOnReportRender = "visible";
    public backGroundElementHeightOnReportRender = "";

    consumerFormControlValues = {
        catalogueValues: null,
        consumerProductList: null,
        commercialProductList: null
    };
    //Control Data

    constructor(private objRenderer: Renderer, private objSubjectSearchDataService: SubjectSearchDataService, public objFormBuilder: FormBuilder, private objRouter: Router, private objRenderSectionDataService: RenderSectionDataService) {
        super();
    }

    public culture: string = currentCulture;
    //Quick search and signla R call
    objSBHub: any;
    objconnection: any;
    private subConsumerTextBox = new Subject();
    public obsConsumerTextBox = this.subConsumerTextBox.asObservable();
    private subCommercialTextBox = new Subject();
    public obsCommercialTextBox = this.subCommercialTextBox.asObservable();

    lastSearchResultStatus: string = "NOTSEARCHED";

    resetCommercialSearchForm() {
        $("#DivSubjectResultBoard").css("visibility", "hidden");
        this.generateNewForm("COMM");
        //this.onSearchTypeChange();      
    }
    resetConsumerSearchForm() {
        $("#DivSubjectResultBoard").css("visibility", "hidden");
        //this.generateNewForm();
        $.when(this.generateNewForm()).then(this.onSearchTypeChange());

    }

    ngOnInit() {

        this.addSession("selectedRUIDs", new Array());
        this.addSession("selectedData", new Array());
        this.addSession("Inq_Mas_ID", "");
        this.addSession("Srch_Con_Score", "");
        this.addSession("Srch_Name", "");

        this.generateNewForm();
        var subjectSearchForm = this;
        this.initiateQuickSearchSocket(subjectSearchForm);
        this.createDatePickerControlls();

        var obsCataLogServer = this.objSubjectSearchDataService.fetchConceptCodeList("conceptCodeList=" + this._requiredDomainCodeList);
        var obsConsumerProductList = this.objSubjectSearchDataService.fetchProductList("CHSType=CONS");
        var obsCommercialProductList = this.objSubjectSearchDataService.fetchProductList("CHSType=COMM");
        Observable.forkJoin(obsCataLogServer, obsConsumerProductList, obsCommercialProductList)
            .subscribe(([obsCataLogServerResult, obsConsumerProductListResult, obsCommercialProductList]) => {
                subjectSearchForm.consumerFormControlValues.catalogueValues = obsCataLogServerResult;
                subjectSearchForm.consumerFormControlValues.consumerProductList = obsConsumerProductListResult;
                subjectSearchForm.consumerFormControlValues.commercialProductList = obsCommercialProductList;

            });
    }

    private createDatePickerControlls() {
        var objConsTextBox = $('#datepickercalendarConsumer');
        this.generateDatePicker(objConsTextBox);
        objConsTextBox.change(function (dateVal) {
            var dateValue = objConsTextBox.data().date;
            datepickchange_cons(dateValue);

        });
        var objCommTextBox = $('#datepickercalendarCommercial');
        this.generateDatePicker(objCommTextBox);
        objCommTextBox.change(function (dateVal) {
            var dateValue = objCommTextBox.data().date;
            datepickchange_comm(dateValue);
        });
    }
    private generateDatePicker(objTextBox: any) {
        objTextBox.datetimepicker({
            pickTime: false,
            icons: {
                time: "fa fa-clock-o",
                date: "fa fa-calendar",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down"
            },
            maxDate: new Date()
        });

    }


    private generateNewForm(defaultSubjectType?: string) {

        if (!defaultSubjectType)
            defaultSubjectType = this._defaultSsubjectType;

        $('#divServiceError').hide();

        this.subjSrchForm = this.objFormBuilder.group({

            RadioButtonCIRType: [defaultSubjectType],
            consumerForm: this.objFormBuilder.group({
                dropDownConsumerSearchType: [this._defaultSearchType, Validators.required],

                consumerNameSearchForm: this.objFormBuilder.group({
                    textboxConsumerName: ["", Validators.required],
                    calendarConsumer: ["", Validators.required],
                    radiobuttonGender: [this._defaultGender, Validators.required],
                    dropDownConsumerNationality: ["", Validators.required],
                    dropDownConsumerIDType: ["", Validators.required],
                    textBoxConsumerID: ["", Validators.required],
                }),
                textBoxConsumerMobile: [{ value: "", disabled: true }, this.validateMobileNumberRequired.bind(this)],
                textboxConsumerAccountNumber: [{ value: "ABC123943113", disabled: true }, this.validateAccountNumberRequired.bind(this)],

                dropdownConsumerProductType: ["", Validators.required],
                dropDownConsumerLoanType: [""]


            }),

            commercialForm: this.objFormBuilder.group({
                dropDownCommercialSearchType: [this._defaultSearchType, Validators.required],
                commercialNameSearchForm: this.objFormBuilder.group({

                    textBoxCommercialName: ["", Validators.required],
                    calendarCommercial: ["", Validators.required],
                    dropDownCommercialIDType: ["", Validators.required],
                    textBoxCommercialID: ["", Validators.required]
                }),
                textBoxCommercialAccountNumber: [{ value: "", disabled: true }, this.validateAccountNumberRequired.bind(this)],
                dropdownCommercialProductType: ["", Validators.required],
                dropDownCommercialLoanType: [""]

            })

        });
        var subjectSearchForm = this;
        this.subjSrchForm.get("RadioButtonCIRType").valueChanges.subscribe(data => {
            this.ClearMergerSessionData();
            $("#DivSubjectResultBoard").css("visibility", "hidden");
            if (data === "CONS") {
                subjectSearchForm.consumerDisplayStyle = "block";
                subjectSearchForm.commercialDisplayStyle = "none";
            } else {
                subjectSearchForm.consumerDisplayStyle = "none";
                subjectSearchForm.commercialDisplayStyle = "block";

            }
            this._subjectType = data;

        });


        var objSearchForm = this.subjSrchForm;
        var lwindowObject = getWindow();
        lwindowObject["datepickchange_cons"] = function (dobValue) {

            var calandorControl = objSearchForm.get(['consumerForm', 'consumerNameSearchForm', 'calendarConsumer']);
            calandorControl.setValue(dobValue);




        }
        lwindowObject["datepickchange_comm"] = function (dobValue) {
            objSearchForm.get(['commercialForm', 'commercialNameSearchForm', 'calendarCommercial']).setValue(dobValue);

        }


    }


    initiateQuickSearchSocket(subjectSearchForm: SubjectSearchComponent) {
        subjectSearchForm.fillKendoAutoComplete("textboxConsumerName", []);
        subjectSearchForm.fillKendoAutoComplete("textBoxCommercialName", []);
        subjectSearchForm.objSBHub = getWindow().$.connection.sBHub;
        subjectSearchForm.objconnection = getWindow().$.connection;
        subjectSearchForm.objconnection.hub.start().done(function () { });

        subjectSearchForm.objSBHub.client.receiveNotification = function (subjectNameList) {
            if (subjectSearchForm._subjectType === "CONS")
                subjectSearchForm.fillKendoAutoComplete("textboxConsumerName", subjectNameList);
            else
                subjectSearchForm.fillKendoAutoComplete("textBoxCommercialName", subjectNameList);

        }
        var objHub = subjectSearchForm.objSBHub;
        subjectSearchForm.objconnection.hub.start().done(function () {
        });//Promise after hub got started

        this.obsConsumerTextBox.debounceTime(100).subscribe(function (data: string) {
            if (data.length > 2)
                objHub.server.sendNotifications(data, true);
        });

        this.obsCommercialTextBox.debounceTime(100).subscribe(function (data: string) {
            if (data.length > 2)
                objHub.server.sendNotifications(data, false);
        });

    }

    public subjectSearch() {
        this.ClearMergerSessionData();
        let isValidForm = false;
        var formValues: string;
        //Consumer Form data fetch
        if (this._subjectType === "CONS") {
            switch (this._subjectSearchType) {
                case "NMIDSRCH":
                    var isValidProduct = this.isValidFormControls(this.subjSrchForm, 'consumerForm', ['dropdownConsumerProductType']);
                    var objConsumerNameSearchForm = <FormGroup>this.subjSrchForm.get(['consumerForm', 'consumerNameSearchForm']);
                    if (objConsumerNameSearchForm.valid && isValidProduct) {
                        formValues = $.param(objConsumerNameSearchForm.value);
                        formValues += "&" + this.fetchFormControlValues(this.subjSrchForm, 'consumerForm', ['dropDownConsumerLoanType', 'dropdownConsumerProductType', 'dropDownConsumerSearchType']);
                        isValidForm = true;
                    }
                    else
                        this.triggerFormGroupValidation(objConsumerNameSearchForm);
                    break;

                case "ACCSRCH":
                    isValidForm = this.isValidFormControls(this.subjSrchForm, 'consumerForm', ['textboxConsumerAccountNumber', 'dropdownConsumerProductType', 'dropDownConsumerSearchType']);
                    if (isValidForm)
                        formValues = this.fetchFormControlValues(this.subjSrchForm, 'consumerForm', ['textboxConsumerAccountNumber', 'dropDownConsumerLoanType', 'dropdownConsumerProductType', 'dropDownConsumerSearchType']);
                    break;
                case "MOBSRCH":
                    isValidForm = this.isValidFormControls(this.subjSrchForm, 'consumerForm', ['textBoxConsumerMobile', 'dropdownConsumerProductType', 'dropDownConsumerSearchType']);
                    if (isValidForm)
                        formValues = this.fetchFormControlValues(this.subjSrchForm, 'consumerForm', ['textBoxConsumerMobile', 'dropDownConsumerLoanType', 'dropdownConsumerProductType', 'dropDownConsumerSearchType']);
                    break;
            }

            formValues += "RadioButtonCIRType=" + this._subjectType;

            this.reportBaseId = 1;//Report Base id form sb_product_detials table


        }

        //Commercial Form data fetch
        if (this._subjectType === "COMM") {
            switch (this._subjectSearchType) {
                case "NMIDSRCH":
                    var isValidProduct = this.isValidFormControls(this.subjSrchForm, 'commercialForm', ['dropdownCommercialProductType']);
                    var objCommercialNameSearchForm = <FormGroup>this.subjSrchForm.get(['commercialForm', 'commercialNameSearchForm']);
                    if (objCommercialNameSearchForm.valid && isValidProduct) {
                        formValues = $.param(objCommercialNameSearchForm.value);
                        formValues += "&" + this.fetchFormControlValues(this.subjSrchForm, 'commercialForm', ['dropDownCommercialSearchType', 'dropDownCommercialLoanType', 'dropdownCommercialProductType']);
                        isValidForm = true;
                    }
                    else
                        this.triggerFormGroupValidation(objCommercialNameSearchForm);
                    break;
                case "ACCSRCH":
                    isValidForm = this.isValidFormControls(this.subjSrchForm, 'commercialForm', ['dropDownCommercialSearchType', 'textBoxCommercialAccountNumber', 'dropdownCommercialProductType']);
                    if (isValidForm)
                        formValues = this.fetchFormControlValues(this.subjSrchForm, 'commercialForm', ['dropDownCommercialSearchType', 'textBoxCommercialAccountNumber', 'dropDownCommercialLoanType', 'dropdownCommercialProductType']);
                    break;
            }
            this.reportBaseId = 2;//Report Base id form sb_product_detials table

        }

        formValues += "RadioButtonCIRType=" + this._subjectType;
        if (isValidForm) {

            this.lastSearchResultStatus = "SEARCHING";

            $("#DivSubjectResultBoard").css("visibility", "hidden");
            this.subjectSearchResult = null;

            this.objRenderSectionDataService.searchSubject(formValues, (this._subjectType == "CONS")).subscribe(objSubjectData => {

                $('#divServiceError').hide();

                if (objSubjectData != null && objSubjectData.LiSubjectInfo == null && objSubjectData.ErrorList != null) {

                    $("#divServiceError").addClass('alert-danger').show();

                    return;
                }

                if (objSubjectData != null && objSubjectData != undefined && objSubjectData.LiSubjectInfo != null && objSubjectData.LiSubjectInfo != undefined && objSubjectData.LiSubjectInfo.length > 0) {
                    this.lastSearchResultStatus = "HIT";
                    objSubjectData.LiSubjectInfo.length
                    this.subjectSearchResult = objSubjectData;
                    this.generatePager(objSubjectData);
                    this.addSession("SubjectInfoList", objSubjectData.LiSubjectInfo);
                    this.addSession("selectedData", new Array());
                    this.addSession("selectedRUIDs", new Array());
                    $("#DivSubjectResultBoard").css("visibility", "visible");
                }
                else {
                    this.lastSearchResultStatus = "NOHIT";
                    this.generateNoHit(objSubjectData);
                }
            });
        }

    }

    // @ViewChild(RptIndexComponent) public rptComponent: RptIndexComponent;
    //Fetch subject details from search result and Trigger report @ server side
    public generateReport(subjectInfo) {

        var selectedRUIDs = this.getSession("selectedRUIDs");

        if (selectedRUIDs.length > 1) {
            if (selectedRUIDs.indexOf(subjectInfo.RUID) < 0 && selectedRUIDs.indexOf(subjectInfo.RUID) < 0) {
                alert("Please click on generate button within selected subject panel");
                return false;
            }

            this.ModelShowMergeRuid(subjectInfo.RUID);

        }
        else {

            var productDropDown = null;
            var productCatalogue = null;
            if (this._subjectType === "CONS") {
                productDropDown = this.subjSrchForm.get(["consumerForm", "dropdownConsumerProductType"]);
                productCatalogue = this.consumerFormControlValues.consumerProductList;
            }
            else {
                productDropDown = this.subjSrchForm.get(["commercialForm", "dropdownCommercialProductType"]);
                productCatalogue = this.consumerFormControlValues.commercialProductList;
            }
            var selectedProductInfo = _(productCatalogue).find((eachProduct) => {
                if (eachProduct.Code === productDropDown.value) return true;
            });


            this.selectedBaseProductId = selectedProductInfo.BaseProductId;
            this.RUIDTogenerateReport = subjectInfo.ACTUALRUID;
            this.reportName = selectedProductInfo.DisplayText;



            var objRequestTriggerRptEngine = new RequestTriggerRptEngine();
            objRequestTriggerRptEngine.ACTUALRUID = subjectInfo.ACTUALRUID;
            objRequestTriggerRptEngine.RUID = subjectInfo.RUID;
            objRequestTriggerRptEngine.CultureCode = 'en-US';
            objRequestTriggerRptEngine.IsCommercial = (this._subjectType === "COMM");
            objRequestTriggerRptEngine.IsNoHit = false;
            objRequestTriggerRptEngine.Product_ID = productDropDown.value;
            objRequestTriggerRptEngine.ReportID = subjectInfo.Inq_Master_ID;
            objRequestTriggerRptEngine.Score = subjectInfo.SearchConfidenceScore;
            objRequestTriggerRptEngine.SearchName = subjectInfo.Name;
            objRequestTriggerRptEngine.UniqueId = "subjectInfo.ACTUALRUID";

            this.makeReportTriggerCall(objRequestTriggerRptEngine);
        }
    }

    public generateNoHit(objSubjectData: any) {
        var objRequestTriggerRptEngine = new RequestTriggerRptEngine();
        if (this._subjectType === "CONS") {
            objRequestTriggerRptEngine.Product_ID = this.subjSrchForm.get(["consumerForm", "dropdownConsumerProductType"]).value;
            this.reportBaseId = 3;
            this.reportName = "Consumer No Hit Report";
        }
        else {
            objRequestTriggerRptEngine.Product_ID = this.subjSrchForm.get(["commercialForm", "dropdownCommercialProductType"]).value;
            this.reportBaseId = 4;
            this.reportName = "Commercial No Hit Report";
        }

        objRequestTriggerRptEngine.ReportID = objSubjectData.InQuiryID;
        objRequestTriggerRptEngine.IsNoHit = true;
        objRequestTriggerRptEngine.IsPDFRequest = false;
        objRequestTriggerRptEngine.CultureCode = "en-US";
        objRequestTriggerRptEngine.UniqueId = "subjectInfo.ACTUALRUID";
        objRequestTriggerRptEngine.Score = 0;

        this.makeReportTriggerCall(objRequestTriggerRptEngine);

    }

    public makeReportTriggerCall(objRequestTriggerRptEngine: RequestTriggerRptEngine) {
        var searchPageObject = this;
        this.objSubjectSearchDataService.triggerReportEngine($.param(objRequestTriggerRptEngine)).subscribe((ReportInfoJson) => {
            searchPageObject.generatedReportId = ReportInfoJson.GeneratedReportId;
            searchPageObject.InquiryMasterId = ReportInfoJson.InquiryMasterId;
            searchPageObject.showReport = true;
            searchPageObject.cirModel.show();
            $("#DivSubjectResultBoard").css("visibility", "hidden"); $("#DivMenuList").css("visibility", "hidden"); $("#DivSubjectSearchForm").css("visibility", "hidden"); $("#DivBranding").css("visibility", "hidden"); $("#DivSubjectResultBoard").css("height", "0"); $("#DivMenuList").css("height", "0"); $("#DivSubjectSearchForm").css("height", "0"); $("#DivBranding").css("height", "0");
        });
    }

    //Calls when closes report popup
    destroyReport() {
        this.ClearMergerSessionData();
        this.backGroundElementViewStatusOnReportRender = "visible";
        this.backGroundElementHeightOnReportRender = "";

        if (this.lastSearchResultStatus != "NOHIT")//If closing nohit report  then no need to show search result grid's pager
            $("#DivSubjectResultBoard").css("visibility", "visible");
        $("#DivMenuList").css("visibility", "visible");
        $("#DivSubjectSearchForm").css("visibility", "visible");
        $("#DivBranding").css("visibility", "visible");
        $("#DivSubjectResultBoard").css("height", "");
        $("#DivMenuList").css("height", "");
        $("#DivSubjectSearchForm").css("height", "");
        $("#DivBranding").css("height", "");

        this.showReport = false;
        this.objRouter.navigate(["SubjectSearch"]);
        this.cirModel.hide();
        this.objRenderSectionDataService.clearReportData();
    }
    closeMergerModel() {
        this.ClearMergerSessionData();
        $("#DivSubjectResultBoard").css("visibility", "visible"); $("#DivMenuList").css("visibility", "visible"); $("#DivSubjectSearchForm").css("visibility", "visible"); $("#DivBranding").css("visibility", "visible"); $("#DivSubjectResultBoard").css("height", ""); $("#DivMenuList").css("height", ""); $("#DivSubjectSearchForm").css("height", ""); $("#DivBranding").css("height", "");
        this.IsModalLoaded = false;
        this.mergeModel.hide();

    }

    //Event handler - Handle search type combo box change event
    onSearchTypeChange() {
        if (this._subjectType === "CONS") {
            this._subjectSearchType = this.subjSrchForm.get(['consumerForm', 'dropDownConsumerSearchType']).value;
            switch (this._subjectSearchType) {
                case "NMIDSRCH":
                    this.subjSrchForm.get(['consumerForm', 'consumerNameSearchForm']).enable();
                    this.subjSrchForm.get(['consumerForm', 'textboxConsumerAccountNumber']).disable();
                    this.subjSrchForm.get(['consumerForm', 'textBoxConsumerMobile']).disable();
                    break;
                case "ACCSRCH":
                    this.subjSrchForm.get(['consumerForm', 'consumerNameSearchForm']).disable();
                    this.subjSrchForm.get(['consumerForm', 'textboxConsumerAccountNumber']).enable();
                    this.subjSrchForm.get(['consumerForm', 'textBoxConsumerMobile']).disable();
                    break;
                case "MOBSRCH":
                    this.subjSrchForm.get(['consumerForm', 'consumerNameSearchForm']).disable();
                    this.subjSrchForm.get(['consumerForm', 'textboxConsumerAccountNumber']).disable();
                    this.subjSrchForm.get(['consumerForm', 'textBoxConsumerMobile']).enable();
                    break;
            }
        }
        else {
            this._subjectSearchType = this.subjSrchForm.get(['commercialForm', 'dropDownCommercialSearchType']).value;

            switch (this._subjectSearchType) {
                case "NMIDSRCH":
                    this.subjSrchForm.get(['commercialForm', 'commercialNameSearchForm']).enable();
                    //this.subjSrchForm.get(['commercialForm', 'textBoxCommercialName']).enable();
                    this.subjSrchForm.get(['commercialForm', 'textBoxCommercialAccountNumber']).disable();

                    break;
                case "ACCSRCH":
                    this.subjSrchForm.get(['commercialForm', 'commercialNameSearchForm']).disable();
                    //this.subjSrchForm.get(['commercialForm', 'textBoxCommercialName']).disable();
                    this.subjSrchForm.get(['commercialForm', 'textBoxCommercialAccountNumber']).enable();

                    break;

            }

        }
    }





    //On key up event raises form consumer name text box field
    consumerNameEnters(obj: Event) {
        var objElementRef = new ElementRef(obj.target);
        this.subConsumerTextBox.next(objElementRef.nativeElement.value);
    }
    //On key up event raises form commercial name text box field
    commercialNameEnters(obj: Event) {
        var objElementRef = new ElementRef(obj.target);
        this.subCommercialTextBox.next(objElementRef.nativeElement.value);
    }


    public isValidFormControls(formObject: FormGroup, groupName: string, controlList: string[]): boolean {
        var isValidControlls = true;
        _(controlList).each((currentControlName) => {
            var controlObject = <FormControl>formObject.get([groupName, currentControlName]);
            if (!controlObject.valid) {
                isValidControlls = false;
                controlObject.markAsDirty();
                controlObject.markAsTouched();
            };
        });
        return isValidControlls;
    }

    public fetchFormControlValues(formObject: FormGroup, groupName: string, controlList: string[]) {
        var controlValue = "";
        _(controlList).each((currentControlName) => {
            controlValue += currentControlName + "=" + <FormControl>formObject.get([groupName, currentControlName]).value + "&";
        });
        return controlValue;

    }
    pager_change(a) {
        var params = "indexnumber=" + a.index + "&consumersearch=" + (this._subjectType === "CONS");
        this.objRenderSectionDataService.searchSubjectWithPager(params).subscribe(objSubjectData => {
            this.subjectSearchResult.LiSubjectInfo = objSubjectData;
        });

    }
    fillKendoAutoComplete(controleName: string, datSource: any) {
        var controlAutoComplete = $("#" + controleName).data("kendoAutoComplete");
        if (controlAutoComplete)
            controlAutoComplete.destroy();

        $("#" + controleName).kendoAutoComplete({
            dataSource: datSource,
            serverFiltering: true,
            filter: "startswith",
            placeholder: "PlaceholderDescription"
        });

        var autocomplete = $("#" + controleName).data("kendoAutoComplete");
        autocomplete.search($("#" + controleName).val());

    }



    public generatePager(objSubjectData: any) {
        var objdataSource = new kendo.data.DataSource({
            data: [],
            pageSize: 3,
            schema: {
                total: function (data) {
                    return objSubjectData.TotalListCount;
                }
            }
        });
        var pager = $("#pager").kendoPager({
            dataSource: objdataSource
        }).data("kendoPager");
        pager.bind("change", this.pager_change.bind(this));
        objdataSource.read();
    }


    validateAccountNumberRequired(objFormControl: FormControl): { [key: string]: boolean } {
        if (this._subjectSearchType === "ACCSRCH" && (_(objFormControl.value).isNull() || _(objFormControl.value.trim()).isEmpty())) {
            return { "validateAccountNumberRequired": true };
        }
        return null;
    }

    validateMobileNumberRequired(objFormControl: FormControl): { [key: string]: boolean } {

        if (this._subjectSearchType === "MOBSRCH" && (_(objFormControl.value).isNull() || _(objFormControl.value.trim()).isEmpty())) {
            return { "validateMobileNumberRequired": true };
        }
        return null;
    }

    public triggerFormGroupValidation(objFormGroup: FormGroup) {
        _(objFormGroup.controls).each((eachControl) => {
            var objeachControl = <FormControl>eachControl;
            objeachControl.markAsDirty();
            objeachControl.markAsTouched();
        });
    }


    public generateReportMerge() {
        var selectedRUIDs = this.getSession("selectedRUIDs");
        var prorityRUIDs = "";
        var subjectInfoLst = this.getSession("SubjectInfoList");

        var filterResult = $(selectedRUIDs).filter(function (idx) {
            return selectedRUIDs[idx] != prorityRUIDs;
        });
        $.each(filterResult, function (i, ob) {

            prorityRUIDs = prorityRUIDs + "," + ob;
        });

        prorityRUIDs = prorityRUIDs.substring(1, prorityRUIDs.length);

        var RUIDListForServer = "";
        var ArrayProrityRUIDs = prorityRUIDs.split(',');
        $.each(ArrayProrityRUIDs, function (PIndex, PElement) {
            var ActualGridObject = $(subjectInfoLst).filter(function (idx) {
                return subjectInfoLst[idx].RUID == PElement;
            });
            RUIDListForServer += ActualGridObject[0].RUID + ",";
        })

        RUIDListForServer = RUIDListForServer.substring(0, RUIDListForServer.length - 1);
        $('#vwConfirmation').modal('hide');

        this.addSession("selectedRUIDs", new Array());

        this.IsModalLoaded = false;
        this.mergeModel.hide();


        var MergedRUID = this.getSession("MergedRUID");
        var MergedName = this.getSession("MergedName");
        var MergedScore = this.getSession("MergedScore");
        var MergedInquiryMasterId = this.getSession("MergedInquiryMasterId");

        var objSubject = {
            RUID: MergedRUID, ACTUALRUID: "",
            Name: MergedName,
            Inq_Master_ID: MergedInquiryMasterId,
            SearchConfidenceScore: MergedScore
        };
        this.generateReport(objSubject);


    }
    public ModelShowMergeRuid(currRUID) {

        var searchPageObject = this;
        this.IsModalLoaded = true;
        this.addSession("currRUID", currRUID);
        searchPageObject.mergeModel.show();

    }

    public ClearMergerSessionData() {
        this.addSession("MergerRUID", "");
        this.addSession("MergedName", "");
        this.addSession("MergedScore", "");
        this.addSession("MergedInquiryMasterId", "");
        this.addSession("selectedRUIDs", new Array());
        this.addSession("SubjectInfoList", new Array());
    }
}



export class RequestTriggerRptEngine {
    ACTUALRUID;
    RUID;
    ReportID;
    CultureCode;
    IsPDFRequest
    IsCommercial;
    Product_ID;
    SearchName;
    Score;
    IsNoHit: boolean;
    UniqueId;
    IsAsyncRequest = true;
    __RequestVerificationToken;

}