import { Component, OnInit } from '@angular/core';
import { CardManager } from "app/services/card-manager-service.";
import { NgForm, FormControl } from "@angular/forms";

@Component({
    selector: 'user-cmp',
    moduleId: module.id,
    templateUrl: 'user.component.html',
    styles: [`input.ng-dirty.ng-invalid {
  border: solid 1px red;
}`]

})

export class UserComponent implements OnInit {
    userCardDetails: any = {};
    isFormSubmitted: boolean;
    constructor(private objCardManager: CardManager) {
    }
    ngOnInit() {
    }
    generateCard(cardFormObject: NgForm) {
        if (!cardFormObject.valid) {
            this.markAsDerty(cardFormObject);
            this.isFormSubmitted = false;
        }
        else {
            this.objCardManager.publishCardDetails(cardFormObject);
            this.isFormSubmitted = true;
        }
    }

    private markAsDerty(cardFormObject: NgForm) {
        for (var eachControl in cardFormObject.controls) {
            (<FormControl>cardFormObject.controls[eachControl]).markAsDirty();
        }
    }
}
